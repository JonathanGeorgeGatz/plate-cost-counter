#!/usr/bin/env python3
"""Independent checker for THE PLATE COST COUNTER — written from spec/SPEC.md alone,
never shown the page's code. Prints the same canonical rounded JSON as tests/run_engine.mjs."""
import sys, json, math, re

WEIGHT = {"g": 1.0, "kg": 1000.0, "oz": 28.3495, "lb": 453.592}
VOLUME = {"ml": 1.0, "l": 1000.0, "tsp": 4.92892, "tbsp": 14.7868, "floz": 29.5735,
          "cup": 236.588, "qt": 946.353, "gal": 3785.41}
COUNT = {"each": 1.0, "dozen": 12.0}

def unit_info(u):
    u = re.sub(r"^fl\s+oz$", "floz", str(u).strip().lower())
    if u in WEIGHT: return ("weight", WEIGHT[u], u)
    if u in VOLUME: return ("volume", VOLUME[u], u)
    if u in COUNT: return ("count", COUNT[u], u)
    return None

def r2(x): return math.floor(x * 100 + 0.5) / 100
def r1(x): return math.floor(x * 10 + 0.5) / 10
def k(s): return str(s).strip().lower()
def is_num(s):
    t = str(s).strip()
    return t != "" and re.match(r"^-?(\d+\.?\d*|\.\d+)$", t) is not None

def parse(text):
    rows = []
    lines = str(text).split("\n")
    lines = [l[:-1] if l.endswith("\r") else l for l in lines]
    for i in range(1, len(lines)):
        if lines[i].strip() == "": continue
        rows.append((i + 1, [f.strip() for f in lines[i].split(",")]))
    return rows

HEADERS = {
    "ingredients": ["ingredient", "pack size", "pack unit", "pack price", "yield %"],
    "recipes": ["dish", "menu price", "ingredient", "qty", "unit"],
    "sales": ["dish", "sold"],
}

def header_ok(text, which):
    first = (str(text).split("\n")[0] or "").rstrip("\r")
    f = [x.strip().lower() for x in first.split(",")]
    return f == HEADERS[which]

def compute(ing_text, rec_text, sales_text, target):
    header_bad = []
    if not header_ok(ing_text, "ingredients"): header_bad.append("ingredients"); ing_text = ""
    if not header_ok(rec_text, "recipes"): header_bad.append("recipes"); rec_text = ""
    if not header_ok(sales_text, "sales"): header_bad.append("sales"); sales_text = ""
    ref_i, ref_r, ref_s = [], [], []
    park_i, park_r, park_s = [], [], []

    ing = {}; seen = {}; status = {}
    ing_rows = parse(ing_text)
    for line, f in ing_rows:
        name = f[0] if f else ""
        if len(f) != 5:
            ref_i.append([line, name.strip(), "wrong number of fields"]); continue
        name, size_s, unit_s, price_s, yield_s = f
        kk = k(name)
        if kk in seen:
            prev = seen[kk]
            if prev[0] == "|".join(k(x) for x in f):
                park_i.append([line, name.strip()]); continue
            ref_i.append([prev[1], prev[2], "conflicting ingredient rows"])
            ref_i.append([line, name.strip(), "conflicting ingredient rows"])
            ing.pop(kk, None); status[kk] = "refused"; seen[kk] = ("<conflict>", line, name.strip())
            continue
        def refuse(why, mark=True):
            ref_i.append([line, name.strip(), why])
            if mark: status[kk] = "refused"; seen[kk] = ("<refused>", line, name.strip())
        if not name.strip():
            ref_i.append([line, "", "blank ingredient name"]); continue
        if not is_num(size_s) or float(size_s) <= 0: refuse("pack size is not a number greater than zero"); continue
        ui = unit_info(unit_s)
        if ui is None: refuse("unknown pack unit “%s”" % unit_s); continue
        if not is_num(price_s) or float(price_s) < 0: refuse("pack price is not a number at or above zero"); continue
        if not is_num(yield_s) or float(yield_s) <= 0 or float(yield_s) > 100: refuse("yield must be a number above 0 and at most 100"); continue
        seen[kk] = ("|".join(k(x) for x in f), line, name.strip())
        ing[kk] = (name.strip(), float(size_s), ui, float(price_s), float(yield_s))
        status[kk] = "ok"

    rec_rows = parse(rec_text)
    order = []; by_dish = {}
    for line, f in rec_rows:
        if len(f) != 5:
            ref_r.append([line, (f[0] if f else "").strip(), "wrong number of fields"]); continue
        dk = k(f[0])
        if dk not in by_dish:
            by_dish[dk] = (f[0].strip(), []); order.append(dk)
        by_dish[dk][1].append((line, f))
    dishes = []
    for dk in order:
        dname, rows = by_dish[dk]
        prices = []
        for _, f in rows:
            if f[1] not in prices: prices.append(f[1])
        d = {"name": dname, "status": None, "flag": None, "why": None, "menuPrice": None,
             "cost": None, "pct": None, "margin": None, "salesNote": None,
             "nLines": 0, "nRefusedLines": 0, "nParkedLines": 0, "_cost": 0.0}
        if len(prices) > 1:
            d["status"] = "refused"; d["why"] = "menu price conflict (%s)" % " vs ".join(prices)
            for line, f in rows: ref_r.append([line, dname, "dish refused: " + d["why"]])
            dishes.append(d); continue
        if not is_num(prices[0]) or float(prices[0]) <= 0:
            tail = "$0" if is_num(prices[0]) else "“%s”" % prices[0]
            d["status"] = "refused"; d["why"] = "no menu price — cannot cost a dish against " + tail
            for line, f in rows: ref_r.append([line, dname, "dish refused: " + d["why"]])
            dishes.append(d); continue
        d["menuPrice"] = float(prices[0])
        seen_lines = set(); cost = 0.0; incomplete = False
        for line, f in rows:
            _, _, iname, qty_s, unit_s = f
            sig = "|".join([dk, k(iname), k(qty_s), k(unit_s)])
            if sig in seen_lines:
                d["nParkedLines"] += 1; park_r.append([line, dname]); continue
            seen_lines.add(sig)
            def refuse_line(why):
                nonlocal incomplete
                d["nRefusedLines"] += 1; ref_r.append([line, dname, why]); incomplete = True
            ik = k(iname)
            if status.get(ik) == "refused":
                refuse_line("ingredient “%s” was refused on the ingredient list" % iname.strip()); continue
            if ik not in ing:
                refuse_line("unknown ingredient “%s”" % iname.strip()); continue
            if not is_num(qty_s) or float(qty_s) <= 0:
                refuse_line("quantity “%s” is not a number above zero — blank or words are not amounts" % qty_s); continue
            ui = unit_info(unit_s)
            if ui is None:
                refuse_line("unknown unit “%s”" % unit_s); continue
            iname2, size, pui, price, yld = ing[ik]
            if ui[0] != pui[0]:
                refuse_line("%s is %s; %s is bought by the %s (%s) — no conversion without a density, so this line is refused"
                            % (ui[2], ui[0], iname2, pui[2], pui[0])); continue
            per_base = price / (size * pui[1]) / (yld / 100.0)
            cost += float(qty_s) * ui[1] * per_base
            d["nLines"] += 1
        d["_cost"] = cost; d["cost"] = cost
        if incomplete:
            d["status"] = "incomplete"
            d["why"] = "%d line(s) refused — partial cost shown, excluded from totals" % d["nRefusedLines"]
        else:
            d["status"] = "costed"
            d["pct"] = cost / d["menuPrice"] * 100.0
            d["margin"] = d["menuPrice"] - cost
            d["flag"] = "OVER TARGET" if d["pct"] > target else "OK"
        dishes.append(d)

    sales_rows = parse(sales_text)
    groups = {}; gorder = []
    for line, f in sales_rows:
        if len(f) != 2:
            ref_s.append([line, (f[0] if f else "").strip(), "wrong number of fields"]); continue
        dk = k(f[0])
        if dk not in by_dish:
            ref_s.append([line, f[0].strip(), "unknown dish — no recipe with this name"]); continue
        if not is_num(f[1]) or float(f[1]) < 0 or float(f[1]) % 1 != 0:
            ref_s.append([line, f[0].strip(), "sold count “%s” is not a whole number at or above zero" % f[1]]); continue
        if dk not in groups: groups[dk] = []; gorder.append(dk)
        groups[dk].append((line, int(float(f[1])), f[0].strip()))
    sales = {}
    for dk in gorder:
        rows = groups[dk]
        counts = sorted(set(r[1] for r in rows), key=lambda c: [r[1] for r in rows].index(c))
        counts = list(dict.fromkeys(r[1] for r in rows))
        if len(rows) == 1: sales[dk] = rows[0]; continue
        if len(counts) == 1:
            sales[dk] = rows[0]
            for r in rows[1:]: park_s.append([r[0], r[2]])
        else:
            for r in rows: ref_s.append([r[0], r[2], "conflicting sales rows (%s) — both refused, no trusted sales" % " vs ".join(str(c) for c in counts)])
            sales[dk] = "conflict"

    money_rows = []; tot = [0.0, 0.0, 0.0, 0.0]; notes = []
    for d in dishes:
        dk = k(d["name"]); s = sales.get(dk)
        if d["status"] == "costed":
            if s == "conflict": d["salesNote"] = "no trusted sales"; continue
            if s is None: d["salesNote"] = "no sales row"; continue
            sold = s[1]
            revenue = d["menuPrice"] * sold
            food = d["_cost"] * sold
            profit = (d["menuPrice"] - d["_cost"]) * sold
            drag = max(0.0, d["_cost"] - d["menuPrice"] * target / 100.0) * sold
            money_rows.append({"dish": d["name"], "sold": sold, "revenue": revenue, "foodCost": food, "profit": profit, "drag": drag})
            for i, v in enumerate([revenue, food, profit, drag]): tot[i] += v
        elif s is not None and s != "conflict":
            notes.append([d["name"], s[1], "dish not costed (%s) — excluded from the money panel" % d["status"]])
    worst = None
    for m in money_rows:
        if worst is None or m["drag"] > worst["drag"]: worst = m
    if worst is not None and worst["drag"] <= 0: worst = None

    n_ing = len(ing_rows)
    checks = []
    for h in header_bad:
        checks.append([h + " header", False, "header row does not name the expected columns — paste not processed"])
    checks.append(["ingredient rows", n_ing == len(ing) + len(park_i) + len(ref_i),
                   "%d = %d + %d + %d" % (n_ing, len(ing), len(park_i), len(ref_i))])
    n_costed = sum(d["nLines"] for d in dishes)
    checks.append(["recipe lines", len(rec_rows) == n_costed + len(park_r) + len(ref_r),
                   "%d = %d + %d + %d" % (len(rec_rows), n_costed, len(park_r), len(ref_r))])
    n_acc = sum(1 for v in sales.values() if v != "conflict")
    checks.append(["sales rows", len(sales_rows) == n_acc + len(park_s) + len(ref_s),
                   "%d = %d + %d + %d" % (len(sales_rows), n_acc, len(park_s), len(ref_s))])
    sums = [sum(m[kk2] for m in money_rows) for kk2 in ("revenue", "foodCost", "profit", "drag")]
    ceq = lambda a, b: abs(a - b) < 0.005
    checks.append(["money re-added", all(ceq(a, b) for a, b in zip(sums, tot)) and ceq(tot[0] - tot[1], tot[2]),
                   "revenue - food cost = profit to the cent"])
    trust = all(c[1] for c in checks)

    out = {
        "target": target, "trust": trust,
        "summary": {
            "costedDishes": sum(1 for d in dishes if d["status"] == "costed"),
            "incompleteDishes": sum(1 for d in dishes if d["status"] == "incomplete"),
            "refusedDishes": sum(1 for d in dishes if d["status"] == "refused"),
            "overTarget": sum(1 for d in dishes if d["flag"] == "OVER TARGET"),
            "ok": sum(1 for d in dishes if d["flag"] == "OK"),
        },
        "dishes": [{
            "name": d["name"], "status": d["status"], "flag": d["flag"], "why": d["why"],
            "menuPrice": None if d["menuPrice"] is None else r2(d["menuPrice"]),
            "cost": None if d["status"] == "refused" else r2(d["_cost"]),
            "pct": None if d["pct"] is None else r1(d["pct"]),
            "margin": None if d["margin"] is None else r2(d["margin"]),
            "salesNote": d["salesNote"], "nLines": d["nLines"],
            "nRefusedLines": d["nRefusedLines"], "nParkedLines": d["nParkedLines"],
        } for d in dishes],
        "money": {
            "rows": [{"dish": m["dish"], "sold": m["sold"], "revenue": r2(m["revenue"]),
                      "foodCost": r2(m["foodCost"]), "profit": r2(m["profit"]), "drag": r2(m["drag"])} for m in money_rows],
            "totals": {"revenue": r2(tot[0]), "foodCost": r2(tot[1]), "profit": r2(tot[2]), "drag": r2(tot[3])},
            "worst": worst["dish"] if worst else None,
        },
        "refusals": {"ingredients": ref_i, "recipes": ref_r, "sales": ref_s},
        "parked": {"ingredients": park_i, "recipes": park_r, "sales": park_s},
        "salesNotes": notes,
        "checks": checks,
    }
    return out

if __name__ == "__main__":
    ing_f, rec_f, sal_f = sys.argv[1:4]
    target = float(sys.argv[4]) if len(sys.argv) > 4 else 30.0
    if target == int(target): target = int(target)
    out = compute(open(ing_f).read(), open(rec_f).read(), open(sal_f).read(), target)
    print(json.dumps(out, indent=1, ensure_ascii=False))
